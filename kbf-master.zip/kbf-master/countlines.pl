while (<>) {};
print $.,"\n";