sh clean.sh
sh getname.sh
sh energy.sh
