#!/bin/bash
>name.txt
rm list*
rm score*.txt
rm *.dat
rm *.gen
rm *.rsa
rm *.log
rm *.asa
rm *.eij
rm batch.*.sh
rm *.pdb
rm KBS_*
rm KBF_*
